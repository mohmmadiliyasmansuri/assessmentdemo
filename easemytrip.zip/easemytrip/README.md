# An automation framework for Challenge - easemytrip.com
Code URl: https://github.com/mohmmadiliyasmansuri/assessmentdemo.git
SSH Key : git@github.com:mohmmadiliyasmansuri/assessmentdemo.git

## Setup
* This framework implementation uses java (Maven), TestNG

Setup (It is assumed that you have java and maven installed globally.)
* Framework uses TestNG to run the tests.
* Install Java.
* Install Maven (https://maven.apache.org/install.html)


## TestCases Covered
* Testing URL: https://www.easemytrip.com/
* Login into application & validate.
* Enter City as Mumbai and Kolkata.
* Select flight booking date prior one month from current date.
* Validate flight serach.
* Check chipest flight.
* Validate all required fileds of chipest flight.


## Note
* properties file is in src\main\java\com\assign\qa\config\config.properties
* Extent report is generated inside ExtentReports folder with test Steps logs, Failed & Passed Screen shot and System info.

## limitation of design
* Date gap for departure is Set for only 30 days.