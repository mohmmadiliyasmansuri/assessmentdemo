package com.assign.qa.testcases;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.assign.qa.base.TestBase;

public class TestSetup extends TestBase {

	@BeforeSuite
	public void setUp() {
		readPropertyFile();
		driverInitialization();
		setExtentReport();
	}
	
	
	@AfterSuite
	public void tearDown() {
		extent.flush();
		driver.quit();
	}
	
	
	
	
}
