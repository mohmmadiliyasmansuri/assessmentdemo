package com.assign.qa.testcases;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.assign.qa.base.TestBase;
import com.assign.qa.pages.FlightInfoPage;
import com.assign.qa.util.utilFunctions;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class CheckPricesTest extends TestBase {

	public static FlightInfoPage flights;

	@BeforeClass
	public void initTest() {
		flights = new FlightInfoPage();
	}

	@Test(priority=0)
	public void validateFlightPriceTest(){

		test = extent.createTest("Validate Lowest Flight Price");
		test.assignCategory("Sanity Test");

		String lowestPrice = flights.getCheapestFlightValue();
		test.log(Status.INFO, "Lowest price of flight is : "+lowestPrice);

		String flightDetails = flights.getCheapestFlightDetails();
		test.log(Status.INFO, "Chepest flight is : "+flightDetails);

		boolean value = false;
		if(flightDetails.contains(lowestPrice)) { 
			value =true; 
		}

		Assert.assertTrue(value);

	}


	@AfterMethod
	public void checkResult(ITestResult result) throws Exception   {

		if (result.getStatus() == ITestResult.FAILURE) {

			test.log(Status.FAIL, result.getName()+" Test Case Failed");
			String screenshotPath = utilFunctions.getScreenshot(result.getName());
			test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
			//test.addScreenCaptureFromPath(screenshotPath);

		} else if (result.getStatus() == ITestResult.SKIP) {
			test.skip(MarkupHelper.createLabel(result.getName()+" Test case Skipped", ExtentColor.YELLOW));
			test.skip(result.getThrowable());

		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.pass(MarkupHelper.createLabel(" Test case passed", ExtentColor.GREEN));
			test.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName())).build());
		}
		//Take screenshots in all cases
		test.addScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName()));

	}


}
