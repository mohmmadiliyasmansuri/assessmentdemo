package com.assign.qa.pages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.assign.qa.base.TestBase;
import com.assign.qa.util.utilFunctions;
public class LoginPage extends TestBase {

	private static final Logger logger = LogManager.getLogger(LoginPage.class);

	@FindBy(xpath="//div[@id='divSignInPnl']/a/span")
	WebElement loginButton;

	@FindBy(xpath="//span[text()='Customer Login']")
	WebElement customerLogin;

	@FindBy(xpath="//input[@id='txtEmail']")
	WebElement email;

	@FindBy(xpath="//input[@type='button' and @value='Continue']")
	WebElement continueBtn;

	@FindBy(xpath="//input[@id='txtEmail2' and @type='password']")
	WebElement password;

	@FindBy(xpath="//div[@id='emailgnBox']/div/div[5]/input")
	WebElement loginSubmit;	
	
	@FindBy(xpath="//span[@id='welcome-det-User']")
	WebElement validateLogin;	
	
	

	// constructor
	public LoginPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	//Action
	utilFunctions util =  new utilFunctions();

	public void selectLoginMenu() {
		try {
			logger.info("Select login menu");
			customWait(500);
			loginButton.click();
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}

	}

	public void selectCustomerLoginMenu() {
		try {
			logger.info("Select customer login option");
			customerLogin.click();
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void provideEmail() {
		try {
			logger.info("Provide Email");
			email.sendKeys(util.getPropertyFile("userName"));
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}

	}

	public void ClickOnContinue() {
		try {
			logger.info("Click on Continue");
			continueBtn.click();
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void providePassword() {
		try {
			logger.info("Provide the password");
			password.sendKeys(util.getPropertyFile("password"));
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void clickOnSubmit() {
		try {
			logger.info("Provide the password");
			loginSubmit.click();
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	public void validateLogin() {
		try {
			logger.info("Validate login successfully");
			String id = validateLogin.getText();
			//logger.info("Extracted ID is : "+id);
			Assert.assertTrue(id.equalsIgnoreCase(util.getPropertyFile("userName")));
			customWait(1000);
		}catch(Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}


}
