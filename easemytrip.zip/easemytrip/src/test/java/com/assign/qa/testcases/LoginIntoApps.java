package com.assign.qa.testcases;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.assign.qa.base.TestBase;
import com.assign.qa.pages.LoginPage;
import com.assign.qa.util.utilFunctions;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class LoginIntoApps extends TestBase {


	@Test
	public void login(){

		try {
			test = extent.createTest("Sign-In into Application ");
			test.assignCategory("Sanity Test");

			LoginPage login = new LoginPage();

			login.selectLoginMenu();
			test.log(Status.INFO, "Clicked on Login button");

			login.selectCustomerLoginMenu();
			test.log(Status.INFO, "Select customer login option");

			login.provideEmail();	
			test.log(Status.INFO, "Entered Email address");

			login.ClickOnContinue();
			test.log(Status.INFO, "Clicked on Continue");

			login.providePassword();	
			test.log(Status.INFO, "Entered password");

			login.clickOnSubmit();
			test.log(Status.INFO, "Clicked on Submit button");

			login.validateLogin();
			test.log(Status.INFO, "Validate the login activity");

		}catch(Exception e) {
			Assert.fail();
			test.log(Status.INFO,"Error : login() ");
		}

	}


	@AfterMethod
	public void checkResult(ITestResult result) throws Exception   {

		if (result.getStatus() == ITestResult.FAILURE) {

			test.log(Status.FAIL, result.getName()+" Test Failed.");
			String screenshotPath = utilFunctions.getScreenshot(result.getName());
			test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
			//test.addScreenCaptureFromPath(screenshotPath);

		} else if (result.getStatus() == ITestResult.SKIP) {
			test.skip(MarkupHelper.createLabel(result.getName()+" Test case Skipped", ExtentColor.YELLOW));
			test.skip(result.getThrowable());

		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel("Test passed", ExtentColor.GREEN));
			test.pass(MarkupHelper.createLabel("Test passed", ExtentColor.GREEN));
			test.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName())).build());
		}
		//Take screenshots in all cases
		test.addScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName()));

	}

}
