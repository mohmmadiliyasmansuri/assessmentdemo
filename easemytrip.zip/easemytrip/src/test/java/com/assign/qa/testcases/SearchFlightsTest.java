package com.assign.qa.testcases;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.assign.qa.base.TestBase;
import com.assign.qa.pages.HomePage;
import com.assign.qa.util.utilFunctions;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class SearchFlightsTest extends TestBase {


	@Test
	public void searchForAFlight(){

		test = extent.createTest("Validate search Flight");
		test.assignCategory("Sanity Test");

		HomePage home = new HomePage();

		home.expandFromCity();
		test.log(Status.INFO, "Clicked on From city");

		home.searchFromCity();	
		test.log(Status.INFO, "Entered from city");

		home.selectFromCity();	
		test.log(Status.INFO, "Select desired From city");

		home.searchToCity();	
		test.log(Status.INFO, "Entered To city");

		home.selectToCity();
		test.log(Status.INFO, "Select desired To city");

		String currDate = home.getCurrentActiveDate();
		test.log(Status.INFO, "Get current active date :"+currDate);

		home.selectDepDates(currDate);
		test.log(Status.INFO, "Select one month prior departure date as :"+currDate);

		home.search();
		test.log(Status.INFO, "clicked the search button");

		home.validateSearchFlightResults();
		test.log(Status.INFO, "Validat search flight page");
	}


	@AfterMethod
	public void checkResult(ITestResult result) throws Exception   {

		if (result.getStatus() == ITestResult.FAILURE) {

			test.log(Status.FAIL, result.getName()+" Test Failed.");
			String screenshotPath = utilFunctions.getScreenshot(result.getName());
			test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
			//test.addScreenCaptureFromPath(screenshotPath);

		} else if (result.getStatus() == ITestResult.SKIP) {
			test.skip(MarkupHelper.createLabel(result.getName()+" Test case Skipped", ExtentColor.YELLOW));
			test.skip(result.getThrowable());

		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel("Test passed", ExtentColor.GREEN));
			test.pass(MarkupHelper.createLabel("Test passed", ExtentColor.GREEN));
			test.pass("Test passed", MediaEntityBuilder.createScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName())).build());
		}
		//Take screenshots in all cases
		test.addScreenCaptureFromPath(utilFunctions.getScreenshot(result.getName()));

	}

}
