package com.assign.qa.pages;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.assign.qa.base.TestBase;
import com.assign.qa.util.utilFunctions;

public class HomePage extends TestBase {

	private static final Logger logger = LogManager.getLogger(HomePage.class);
	utilFunctions util =  new utilFunctions();

	// object factory
	@FindBy(xpath="//input[@id='FromSector_show']")
	WebElement expandFromCity;

	@FindBy(xpath="//input[@id='a_FromSector_show']")
	WebElement searchFromCity;

	@FindBy(xpath="//span[contains(@id,'spn') and @class = 'flsctrhead']")
	List<WebElement> searchCityResults;

	@FindBy(xpath="//input[@id='a_Editbox13_show']")
	WebElement searchToCity;

	@FindBy(xpath="//li[@class='active-date']")
	WebElement currentActiveDate;

	@FindBy(xpath="//div[@class='days']/ul/li")
	List<WebElement> allAvailableDates;

	@FindBy(xpath="//div[@id='showOWRT']/div/div[8]/button")
	WebElement searchBtn;
	
	@FindBy(xpath="//div[@id='divFltMain']/div[2]/div[2]/div[2]/a[1]")
	WebElement flightresults;
	
	



	// constructor
	public HomePage() {
		super();
		PageFactory.initElements(driver, this);
	}

	// actions

	public void expandFromCity() {
		try {
			logger.info("Expand From city");
			expandFromCity.click();
			customWait(500);
		}catch(Exception e) {
			logger.error("Error : expandFromCity()");
			e.printStackTrace();
			Assert.fail();

		}
	}

	String fromCity = util.getPropertyFile("From");
	public void searchFromCity() {
		try {
			logger.info("Provide From city");
			searchFromCity.sendKeys(fromCity);;
			customWait(500);
		}catch(Exception e) {
			logger.error("Error : searchFromCity()");
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void selectFromCity() {
		try {
			logger.info("Select From city");
			searchCityResults.get(0).click();
			customWait(500);
		}catch(Exception e) {
			logger.error("Error : selectFromCity()");
			e.printStackTrace();
			Assert.fail();
		}
	}

	String toCity=util.getPropertyFile("To");
	public void searchToCity() {
		try {
			logger.info("Provide To city");
			searchToCity.sendKeys(toCity);
			customWait(500);
		}catch(Exception e) {
			logger.error("Error : searchToCity()");
			e.printStackTrace();
			Assert.fail();
		}
	}

	public void selectToCity() {
		try {
			logger.info("Select To city");
			int size = searchCityResults.size();
			String town = toCity.toLowerCase(); 
			for(int i =0;i<size;i++) {
				String city = searchCityResults.get(i).getText().toLowerCase();
				//System.out.println("Extracted To city is :"+city);
				if(city.contains(town)) {
					searchCityResults.get(i).click();
				}
			}
		}catch(Exception e) {
			logger.error("Error : selectToCity()");
			e.printStackTrace();
			Assert.fail();
		}
	}

	public String getCurrentActiveDate() {
		String curDates = null;
		try {
			logger.info("Get the current date");
			curDates = currentActiveDate.getText();
			//System.out.println("Current active date is : "+curDates);
			return curDates;
		}catch(Exception e) {
			logger.error("Error : getCurrentActiveDate()");
			e.printStackTrace();
			Assert.fail();
		}
		return curDates;
	}


	public void selectDepDates(String dateToSelect) {
		try {
			logger.info("Select the departure date one month prior from today");
			int dateSize = allAvailableDates.size();
			int flag =0;
			for(int i=0;i<dateSize;i++) {
				String date = allAvailableDates.get(i).getText();
				String[] parts = date.split("\\D+");
				date = parts[0].trim();
				//System.out.println("Extracted date is : "+date);
				if(date.equalsIgnoreCase(dateToSelect)) {
					flag = flag+1;
					if(flag==2) {
						allAvailableDates.get(i).click();
						break;
					}
				}

			}
			customWait(500);
		}catch(Exception e) {
			logger.error("Error : selectDepDates()");
			e.printStackTrace();
			Assert.fail();
		}

	}

	public FlightInfoPage search() {
		try {
			logger.info("Click on Submit button");
			searchBtn.click();
			customWait(5000);
			driver.manage().deleteAllCookies();
		}catch(Exception e) {
			logger.error("Error : FlightInfoPage()");
			e.printStackTrace();
			Assert.fail();
		}
		return new FlightInfoPage();

	}
	
	public void validateSearchFlightResults() {
		try {
			logger.info("Validate Search flight results");
			String pDays = flightresults.getText().trim();
			String actualDay = "Previous Day";
			Assert.assertEquals(pDays, actualDay);
		}catch(Exception e) {
			logger.error("Error : validateSearchFlightResults()");
			e.printStackTrace();
			Assert.fail();
		}
		
	}




}
