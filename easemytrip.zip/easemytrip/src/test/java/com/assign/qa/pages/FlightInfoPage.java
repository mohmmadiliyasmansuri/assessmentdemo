package com.assign.qa.pages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.assign.qa.base.TestBase;

public class FlightInfoPage extends TestBase{

	private static final Logger logger = LogManager.getLogger(FlightInfoPage.class);

	// Page factory
	@FindBy(xpath="//span[@class='top_chpst']/following-sibling::span")
	WebElement cheapestFlightMsg;

	@FindBy(xpath="//span[@class='top_chpst']/following::div[1]")
	WebElement getCheapestFlightDetails;


	//initialization
	public FlightInfoPage() {
		PageFactory.initElements(driver, this);
	}

	String lowestAmount = null;
	public String getCheapestFlightValue() {
		try {
			logger.info("Get the cheapest Fair Msg");
			lowestAmount = cheapestFlightMsg.getText();
			//System.out.println("Cheapest Message is : "+lowestAmount);
			String[] parts = lowestAmount.split("\\D+");
			lowestAmount = parts[1].trim();
			//System.out.println("Amount is : "+lowestAmount);
		}catch(Exception e) {
			logger.error("Error : getCheapestFlightValue()");
			e.printStackTrace();
			Assert.fail();
		}
		return lowestAmount;
	}

	public String getCheapestFlightDetails() {

		String details = null;
		try {
			logger.info("Get the details of cheapest cheapest flight");
			String start = "//span[@class='top_chpst']/following::div/span[@class='";
			String end = "']";
			WebElement flightDetails = getCheapestFlightDetails;
			String airLName = driver.findElements(By.xpath(start+"txt-r4 ng-binding"+end)).get(0).getText();
			String airLCode = flightDetails.getAttribute("aircode");
			String airLNumber = flightDetails.getAttribute("fn");
			String airLineNumber = airLCode+" - "+airLNumber;
			String deptm = flightDetails.getAttribute("deptm");
			String arrtm = flightDetails.getAttribute("arrtm");
			String airLineTiming = "Departure Time : "+deptm+" ---> "+"Arrival Time : "+arrtm;
			String fromCty = driver.findElements(By.xpath(start+"txt-r3-n ng-binding"+end)).get(0).getText();
			String toCty = driver.findElements(By.xpath(start+"txt-r3-n ng-binding"+end)).get(1).getText();
			String fromToCity = "From City : "+fromCty+" ---> "+"To City : "+toCty;
			String price = flightDetails.getAttribute("price");
			int lowestPrc= Integer.parseInt(lowestAmount);
			int lowestValue = Integer.parseInt(price);
			if(lowestValue>=lowestPrc) {
				price=lowestAmount;
			}
			//start = "//span[@class='top_chpst']/following::div[@class='";
			//end =  "']/span";
			//String price = driver.findElements(By.xpath(start+"txt-r6-n ng-scope"+end)).get(0).getText();
			price = "Rs."+price;
			details = airLName+" , "+airLineNumber+" , "+airLineTiming+" , "+fromToCity+" , "+price;
			//System.out.println("Cheapest flight details are : "+details);

		}catch(Exception e) {
			logger.error("Error : getCheapestFlightDetails()");
			e.printStackTrace();
			Assert.fail();
		}
		return details;
	}


	public int covertToMoney(String raw) {
		//departurePriceBox.getText() -> Rs 7,924
		//(departurePriceBox.getText()).split(" ")[1] -> 7,924
		//(departurePriceBox.getText()).split(" ")[1].replaceAll(",$", "") -> 7924
		return Integer.parseInt(raw.split(" ")[1].replace(",", ""));
	}



}
